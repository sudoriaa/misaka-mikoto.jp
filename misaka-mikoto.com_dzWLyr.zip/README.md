<a href="https://github.com/misaka-fans/misaka-fans.github.io" target="_blank"><img src="https://img.shields.io/github/stars/misaka-fans/misaka-fans.github.io" /></a>

# Misaka Mikoto

你指尖跃动的电光，是我此生不变的信仰！

![爱我炮姐](https://github.com/shbwb/misaka/blob/main/pic/0EE7D24A-F64D-4818-AEE8-E5C83A5696B3.jpeg)

网站 URL：https://misaka-fans.github.io

# 关于这个项目

## 这个项目是做什么的？

**0、让更多人了解御坂美琴**

**1、炮厨聚集地**

如果你拥有一个 GitHub 账号，不妨点一下右上角的 star，支持一下这个项目，<del>让它活得更久，</del>让更多人发现它吧～

在这个 GitHub 仓库中，你可以发起任何有关炮姐的 issue，欢迎前来讨论～

**2、照片收集**

在满足上一项条件后，你可以通过[fork](https://github.com/misaka-fans-photos/misaka-fans-photos.github.io/fork)，并提交 Pull Request 的方式，提交自己创作的功能。

## 贡献者

说明：对于对此项目有贡献的炮厨，TA 的 GitHub 账户名，将会展现在[About](https://misaka-mikoto.jp/pages/about)页面。

## 开发

图片 CDN

```
https://misaka-fans-photos.github.io/

https://img.misaka-mikoto.jp/
```

插件：Pio 看板娘

镜像网站：https://misaka-fans.netlify.app
(Netlify)--本人在使用网易云电脑测试访问时（浏览器：edge，系统：Windows10），发现 GitHub pages 会重定向至错误网站，镜像备份访问正常。此页面大量劫持无辜网页！
以下是该页面的[Q&A](https://dragonstatic.com/q-a.html)

```
我的域名停放在海外平台的，为何会跳转至此？
那是因为您所停放的平台与我们有合作，将中国大陆地区的访问量跳转至此。
相信您也有获得相关的广告分成！
```

但我从始至终没有收过一分钱，建站全是出于对御坂美琴这个角色的喜爱！（GitHub pages 自动续签 ssl 证书，也不存在域名过期，这让我很生气。如果无法访问，请使用镜像。有了解这方面的朋友可以教教我。）
